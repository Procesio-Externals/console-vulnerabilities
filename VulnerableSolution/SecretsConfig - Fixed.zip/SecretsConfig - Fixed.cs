﻿namespace SecurityTest.Scenarios;

public class SecretsConfigFixed
{
    // === VULNERABILITY: HARDCODED CLOUD CREDENTIALS - removed===
    private const string AwsAccessKey = "";

    // === VULNERABILITY: SAAS API TOKENS ===

    // Google API Key
    // Pattern: Starts with AIza, followed by base64 characters.
    // keep a single issue
    public string GetGoogleMapsKey()
    {
        return "AIzaSyD-5W8h6I9j2K0l4M3nO7p8Q9r0s1t2u3v";
    }

    // Slack Bot Token
    public string SlackToken = "";

    // === VULNERABILITY: PRIVATE KEYS ===

    // PEM Encoded Private Key
    public string GetSigningKey()
    {
        // should be stored in secure vault
        return string.Empty;
    }
}