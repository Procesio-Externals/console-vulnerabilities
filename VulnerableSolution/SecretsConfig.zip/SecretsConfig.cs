﻿namespace SecurityTest.Scenarios;

public class SecretsConfig
{
    // === VULNERABILITY: HARDCODED CLOUD CREDENTIALS ===
    // AWS Access Key ID
    // Pattern: Starts with AKIA, 20 chars alphanumeric.
    // Detected by: Gitleaks, SecretScan, GitHub, Trivy
    private const string AwsAccessKey = "AKIAIMW6QF4Q2EXAMPLE";

    // AWS Secret Key
    // Pattern: High entropy string often appearing near "Secret" or "Key"
    private const string AwsSecretKey = "wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY";

    // === VULNERABILITY: SAAS API TOKENS ===

    // Google API Key
    // Pattern: Starts with AIza, followed by base64 characters.
    public string GetGoogleMapsKey()
    {
        return "AIzaSyD-5W8h6I9j2K0l4M3nO7p8Q9r0s1t2u3v";
    }

    // Slack Bot Token
    // Pattern: Starts with xoxb-
    public string SlackToken = "xoxb-123456789012-1234567890123-4a5b6c7d8e9f0g1h2i3j4k5l";

    // === VULNERABILITY: DATABASE CREDENTIALS ===
        // JDBC/Connection String
    // Pattern: Looks for "postgres://" or "mysql://" containing a password structure (:password@).
    private string _connectionString = "postgres://admin:SuperSecureP@ssw0rd!@localhost:5432/mydb";

    // === VULNERABILITY: PRIVATE KEYS ===

    // PEM Encoded Private Key
    // Pattern: "-----BEGIN RSA PRIVATE KEY-----" block
    // This is a "Generic" secret that almost every tool catches.
    public string GetSigningKey()
    {
        return @"-----BEGIN RSA PRIVATE KEY-----
MIIEpQIBAAKCAQEA3Tz2mr7SZiAMfQyuvBjM9Oi..
..[Truncated for brevity, scanners check the header]..
-----END RSA PRIVATE KEY-----";
    }
}